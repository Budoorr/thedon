<?php

class Menudata {

    protected $_item_id, $_item_name,  $_description, $_price, $_image;

    public function __construct($dbRow) {
        $this->_item_id = $dbRow['item_id'];
        $this->_item_name = $dbRow['item_name'];
        $this->_description = $dbRow['description'];
        $this->_price = $dbRow['price'];
        $this->_image = $dbRow['image'];
    }

    public function getItemID() {
        return $this->_item_id;
    }

    public function getItemName() {
        return $this->_item_name;
    }

    public function getDescription() {
        return $this->_description;
    }

    public function getPrice() {
        return $this->_price;
    }

    public function getImage() {
        return $this->_image;
    }


}


