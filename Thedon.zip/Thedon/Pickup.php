<?php


require_once('Models/Menudataset.php');

$view = new stdClass();

$MenuData = new Menudataset();
$view->Menudataset = $MenuData->fetchAllMenu();

require_once('Views/Pickup.phtml');

