<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Bootstrap core CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">

</head>

<body role=""document">

<div class="container">
    <div  class="row">
        <div id="title" class="col-xs-12">
            <img src="images/new_uos_logo.jpg" alt="Salford University" />
            <div class="pull-right"> <h1> </h1></div>
            <!--<?php echo $view->pageTitle ?>-->
        </div>
    </div>


    <div class="row">
        <nav id="menu" class="col-xs-6 col-sm-3 col-md-2">
            <h2>Menu</h2>
            <ul class="nav flex-column">
                <li><a href="index.php">Home</a></li>
                <li><a href="Pickup.php">About</a></li>


            </ul>
        </nav>

        <main id="content" class="col-xs-6 col-sm-9 col-md-10">



